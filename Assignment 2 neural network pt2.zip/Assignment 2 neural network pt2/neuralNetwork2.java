//Co'Niya Butler
//10383733
//October 24, 2023
//Assignment 2
// This is part two of the assignment, in which the weights and biases are hard-coded, there's an epoch loop that goes through 6000 mini-batches, and each batch goes through the inputs and trains the network to get the correct output.
//uses various helper functions to calculate values, zero out matrices, transpose matrices, and 

//import packages
package neuralNetwork2;
import java.util.Arrays;
import java.io.*;
import java.util.Random;
import java.util.Scanner;
import java.io.File;

public class neuralNetwork2 {
			//size of each layer
			public static int inputSize = 784; //pixels to picture
			public static int hiddenSize = 15;
			public static int outputSize = 10;
			public static int miniBatchSize = 10;
			
			//initialize weights with random doubles between each layer
			public static double[][] weightsInputToHidden = initRand(new double[hiddenSize][inputSize]);
			public static double[][] weightsHiddenToOutput = initRand(new double[outputSize][hiddenSize]);
		
			//initialize biases
			public static double[][] biasesToHidden = initRand(new double[hiddenSize][1]);
			public static double[][] biasesToOutput = initRand(new double[outputSize][1]);
			
			//instantiate learning rate and num of epochs
			public static double learningRate = 3;
			public static int epochs = 30;
			
			//weights and bias error sum. used to hold the sum of the error in
			//output/hidden layer
			public static double[][] weightHiddenErrorSum = new double[hiddenSize][inputSize]; 
			public static double[][] weightOutputErrorSum = new double[outputSize][hiddenSize] ; 
			public static double[][] biasHiddenErrorSum = new double[hiddenSize][1];
			public static double[][] biasOutputErrorSum = new double[outputSize][1] ; 
			
			//training data and one hot matrix created using an array of arrays
			//at 60000 since its the size of the training data
			public static int[][] trainingOneHot = new int[60000][outputSize];
			public static double[][] trainingData = new double[60000][inputSize];
			
			//testing data and one hot matrix created using an array of arrays
			//at 10000 since its the size of the testing data
			public static double[][] testingData = new double[10000][inputSize];
			public static int[][] testingOneHot = new int[10000][outputSize];
			
			//network accuracy variables
			//initialize to 0
			public static int total = 0;
			public static int correct = 0;
			
			//initialize network accuracy arrays used to calculate and print how many of each number is correctly guessed and the total amount that it was seen
			public static int[] totalA = new int[10];
			public static int[] correctA = new int[10];
			
	public static void main(String[] args) {
		//reading the data from the csv file and putting the values in my "matrices"
		System.out.println("Loading training data...\n");
		readImport("data/mnist_train.csv", trainingData, trainingOneHot);
		
		System.out.println("Loading testing data...\n");
		readImport("data/mnist_test.csv", testingData, testingOneHot);
		
		//user selection menu
		System.out.println("[1] Train the network" + "\n[2] Load a pre-trained network" + "\n[0] Exit");
		//reading user input from the command line
		Scanner in = new Scanner(System.in);
		for(;;) {
			//use the value from the command line to run one of the following options from the menu
			int menu = in.nextInt();
			switch(menu) {
			case 0:
				System.exit(0);
			//train the data
			case 1:
				training();
				break;
			//load previously saved network
			case 2:
				loadNetworkState();
				break;
			//show the accuracy for the training
			case 3:
				testingForTrain();
				break;
			//show the accuracy for the testing
			case 4:
				testingForTest();
				break;
			//test the data display all values correct and incorrectly classified
			case 5:
				testAndDisplay();
				break;
			//test and display only the incorrectly classified values
			case 6:
				testAndDisplayIncorrect();
				break;
			//save the current state of the network
			case 7:
				saveNetworkState();
				break;
			}
			//full menu only available after 1 or 2 pressed
			System.out.println("[1] Train the network" + "\n[2] Load a pre-trained network" + "\n[3] Display network accuracy on TRAINING data" + "\n[4] Display network accuracy on TESTING data" + "\n[5] Run network on TESTING data showing images and labels" + "\n[6] Display the misclassified TESTING images" + "\n[7] Save the network state to file" +"\n[0] Exit");
		}
	}
	//training function
	public static void training() {
		//epoch loop goes to 6 epochs as instantiated earlier and it loops the two batches each epoch 
		for(int epoch = 1; epoch <= epochs; epoch++){
			System.out.println("\nEpoch " + epoch);
			System.out.println();
			
			//reset all network accuracy to 0 after each epoch
			correct = 0;
			total = 0;
			zeroOutInt(correctA);
			zeroOutInt(totalA);
			
			//randomize mini-batch
			int[] randMiniBatchArray = randMiniBatch();
			
			//iterate through a mini-batch which is evenly split by the overall data size which 60000/10(digits) = 6000 mini-batches
			//so one mini-batch will have 10 digits that have been processed
			int currMiniBatchSize = 60000/miniBatchSize;
			for(int currMiniBatch = 0, firstIndex = 0, secondIndex = miniBatchSize; currMiniBatch < currMiniBatchSize; currMiniBatch++, firstIndex+=miniBatchSize, secondIndex+=miniBatchSize) {
				//mini-batch
				//use the data from the first mini-batch that was randomized at first, and use the expected output(one hot vector)
				//to find the error output until it "learns" to match the expected output 
				for(int miniBatch = firstIndex; miniBatch < secondIndex; miniBatch++){
					double[] currInput = trainingData[randMiniBatchArray[miniBatch]];
					int[] expectedOutput = trainingOneHot[randMiniBatchArray[miniBatch]];
					
					//forward transversal
					double hiddenLayerActivations[][] = new double[hiddenSize][1];
					double outputLayerActivations[][] = new double[outputSize][1];
					
					//transpose matrix
					double[][] transposedCurrInput = transposeSingDouble(currInput);
					
					//input to hidden
					//loop to summation from 0 up to the size of the layer by multiplying the matrices
					//of the input and the weights and then added to the bias and then use the answer in the sigmoid
					//function
					for(int i = 0; i < hiddenSize; i++){
						for(int j = 0; j < transposedCurrInput[0].length; j++){
							double prod = 0;
							for(int k = 0; k < inputSize; k++) {
								prod += weightsInputToHidden[i][k] * transposedCurrInput[k][j];
							}
							hiddenLayerActivations[i][j] = prod;
						}
					}
					
					
					for(int i = 0; i < hiddenSize; i++){
						for(int j = 0; j < 1; j++){
							hiddenLayerActivations[i][j] += biasesToHidden[i][j];
						}
					}
					
					for(int i = 0; i < hiddenSize; i++){
						for(int j = 0; j < 1; j++){
							hiddenLayerActivations[i][j] = sigmoid(hiddenLayerActivations[i][j]);
						}
					}
					
					//hidden to output
					//loop to summation from 0 up to the size of the layer by multiplying the matrices
					//of the input and the weights and then added to the bias and then use the answer in the sigmoid
					//function
					for(int i = 0; i < outputSize; i++){
						for(int j = 0; j < 1; j++){
							double prod = 0;
							for(int k = 0; k < hiddenSize; k++) {
								prod += hiddenLayerActivations[k][j] * weightsHiddenToOutput[i][k];
							}
							outputLayerActivations[i][0] = prod;
						}
						outputLayerActivations[i][0] += biasesToOutput[i][0];
						outputLayerActivations[i][0] = sigmoid(outputLayerActivations[i][0]);
					}
					
					//check to see if correct number was guessed
					//increment the total number of values that was trained (i.e. 60000)
					total += 1;
					totalA[indexHotVect(transposeInt(expectedOutput))] += 1;
					//if expected output and the classified value are equal update the amount correctly classified and the amount of that digit correctly classified
					if(indexOutputActivation(outputLayerActivations) == indexHotVect(transposeInt(expectedOutput))) {
						correct += 1;
						correctA[indexOutputActivation(outputLayerActivations)] += 1;
					}

					//backpropagation
					double[][] outputLayerErrors = new double[outputSize][1]; //bias gradient
					double[][] hiddenLayerErrors = new double[hiddenSize][1]; //bias gradient
					
					double[][] outputWeightLayerErrors = new double[outputSize][hiddenSize]; //weight gradient
					double[][] hiddenWeightLayerErrors = new double[hiddenSize][inputSize]; //weight gradient
					
					//find the bias gradient in the final layer and use that gradient to find the weight gradient for the output layer
					for(int i = 0; i < outputSize; i++){
						outputLayerErrors[i][0] = (outputLayerActivations[i][0] - expectedOutput[i]) * sigmoidDerivative(outputLayerActivations[i][0]);
					}
					
					// bias gradient summation
					for(int i = 0; i < outputLayerErrors.length; i++) {
						for(int j = 0; j < outputLayerErrors[i].length; j++) {
							biasOutputErrorSum[i][j] += outputLayerErrors[i][j] ;
						}
					}
					
					// get output weight gradient 
					// outputLayerError * hiddenLayerOutput 
					double[] transposedHiddenOutput = transposeDouble(hiddenLayerActivations);
					for(int i = 0; i < outputWeightLayerErrors.length;i++) {
						for(int j = 0; j < transposedHiddenOutput.length;j++) {
							outputWeightLayerErrors[i][j] = outputLayerErrors[i][0] * transposedHiddenOutput[j];
						}
					}
					for(int i = 0; i < outputWeightLayerErrors.length; i++) {
						for(int j = 0; j < outputWeightLayerErrors[0].length; j++) {
							weightOutputErrorSum[i][j] += outputWeightLayerErrors[i][j];
						}
					}
					
					//get the error from the hidden layer and use this error to find the bias gradient for the hidden layer
					for(int i = 0; i < hiddenSize; i++){
						double error = 0;
						for(int j = 0; j < outputSize; j++){
							error += outputLayerErrors[j][0] * weightsHiddenToOutput[j][i];
						}
						hiddenLayerErrors[i][0] = error;
					}
					
					for(int i = 0; i < hiddenLayerErrors.length; i++) {
							hiddenLayerErrors[i][0] *= sigmoidDerivative(hiddenLayerActivations[i][0]);
					}
					
					for(int i = 0; i < hiddenLayerErrors.length; i++) {
						for(int j = 0; j < hiddenLayerErrors[i].length; j++) {
							biasHiddenErrorSum[i][j] += hiddenLayerErrors[i][j] ;
						}
					}
					
					// get hidden weight gradient 
					// outputLayerError * hiddenLayerOutput 
					for(int i = 0; i < biasHiddenErrorSum.length;i++) {
						for(int j = 0; j < currInput.length;j++) {
							hiddenWeightLayerErrors[i][j] += hiddenLayerErrors[i][0] * currInput[j];
						}
					}
					for(int i = 0; i < hiddenWeightLayerErrors.length; i++) {
						for(int j = 0; j <hiddenWeightLayerErrors[0].length; j++) {
							weightHiddenErrorSum[i][j] += hiddenWeightLayerErrors[i][j];
						}
					}
				}
				//update weights and biases
				//use the error calculations to update the weights and biases based on the learning rate
				for(int i = 0; i < outputSize; i++){
					for(int j = 0; j < hiddenSize; j++){
						weightsHiddenToOutput[i][j] -= (learningRate * weightOutputErrorSum[i][j])/2;
					}
					biasesToOutput[i][0] -= (learningRate * biasOutputErrorSum[i][0])/2; 
				}
				for(int i = 0; i < hiddenSize; i++){
					for(int j = 0; j < inputSize; j++){
						weightsInputToHidden[i][j] -= (learningRate * weightHiddenErrorSum[i][j])/2;
					}
					biasesToHidden[i][0] -= (learningRate * biasHiddenErrorSum[i][0])/2;
				}
				
				// Zero out summation matrices
				zeroOut(weightHiddenErrorSum);
				zeroOut(weightOutputErrorSum);
				zeroOut(biasHiddenErrorSum);
				zeroOut(biasOutputErrorSum);
			}
			//printing out the accuracy after each epoch
			for(int i = 0; i < 10; i++) {
				if(i == 6) {
					System.out.println("\n");
				}
				String calcs = String.format("%d = %d / %d ", i, correctA[i], totalA[i]);
				System.out.print(calcs);
			}
			// print out the overall accuracy after all epochs are finished
			String trainingDataAccuracy = String.format("\nnetwork accuracy: %d / %d = %f", correct, total, ((double)correct/(double)total)*100);
			System.out.println(trainingDataAccuracy);
		}
	}
	//testing function
	public static void testingForTrain() {
		//epoch loop goes to 1 epochs as instantiated earlier and it loops the 10 batches for the epoch
				for(int epoch = 1; epoch < 2; epoch++){
					correct = 0;
					total = 0;
					zeroOutInt(correctA);
					zeroOutInt(totalA);
					
						//mini-batch
						//use the data from the input, and use the expected output to calculate the network accuracy
						for(int miniBatch = 0; miniBatch < 60000; miniBatch++){
							double[] currInput = trainingData[miniBatch];
							int[] expectedOutput = trainingOneHot[miniBatch];
							
							//forward transversal
							double hiddenLayerActivations[][] = new double[hiddenSize][1];
							double outputLayerActivations[][] = new double[outputSize][1];
							
							//transpose matrix
							double[][] transposedCurrInput = transposeSingDouble(currInput);
							
							//input to hidden
							//loop to summation from 0 up to the size of the layer by multiplying the matrices
							//of the input and the weights and then added to the bias and then use the answer in the sigmoid
							//function
							for(int i = 0; i < hiddenSize; i++){
								for(int j = 0; j < transposedCurrInput[0].length; j++){
									double prod = 0;
									for(int k = 0; k < inputSize; k++) {
										prod += weightsInputToHidden[i][k] * transposedCurrInput[k][j];
									}
									hiddenLayerActivations[i][j] = prod;
								}
							}
							
							
							for(int i = 0; i < hiddenSize; i++){
								for(int j = 0; j < 1; j++){
									hiddenLayerActivations[i][j] += biasesToHidden[i][j];
								}
							}
							
							for(int i = 0; i < hiddenSize; i++){
								for(int j = 0; j < 1; j++){
									hiddenLayerActivations[i][j] = sigmoid(hiddenLayerActivations[i][j]);
								}
							}
							
							//hidden to output
							//loop to summation from 0 up to the size of the layer by multiplying the matrices
							//of the input and the weights and then added to the bias and then use the answer in the sigmoid
							//function
							for(int i = 0; i < outputSize; i++){
								for(int j = 0; j < 1; j++){
									double prod = 0;
									for(int k = 0; k < hiddenSize; k++) {
										prod += hiddenLayerActivations[k][j] * weightsHiddenToOutput[i][k];
									}
									outputLayerActivations[i][0] = prod;
								}
								outputLayerActivations[i][0] += biasesToOutput[i][0];
								outputLayerActivations[i][0] = sigmoid(outputLayerActivations[i][0]);
							}
							
							//check to see if correct number was guessed
							total += 1;
							totalA[indexHotVect(transposeInt(expectedOutput))] += 1;
							if(indexOutputActivation(outputLayerActivations) == indexHotVect(transposeInt(expectedOutput))) {
								correct += 1;
								correctA[indexOutputActivation(outputLayerActivations)] += 1;
							}
						}
					}
					//printing out the accuracy
					for(int i = 0; i < 10; i++) {
						if(i == 6) {
							System.out.println("\n");
						}
						String calcs = String.format("%d = %d / %d ", i, correctA[i], totalA[i]);
						System.out.print(calcs);
					}
					System.out.println(String.format("network accuracy: %d / %d = %f", correct, total, ((double)correct/(double)total)*100));
	
	}
	//testing function
	public static void testingForTest() {
		//epoch loop goes to 1 epochs as instantiated earlier and it loops the 10 batches for the epoch
		for(int epoch = 1; epoch < 2; epoch++){
			correct = 0;
			total = 0;
			zeroOutInt(correctA);
			zeroOutInt(totalA);
			
				//mini-batch
				//use the data from the input, and use the expected output to calculate the network accuracy
				for(int miniBatch = 0; miniBatch < 10000; miniBatch++){
					double[] currInput = testingData[miniBatch];
					int[] expectedOutput = testingOneHot[miniBatch];
					
					//forward transversal
					double hiddenLayerActivations[][] = new double[hiddenSize][1];
					double outputLayerActivations[][] = new double[outputSize][1];
					
					//transpose matrix
					double[][] transposedCurrInput = transposeSingDouble(currInput);
					
					//input to hidden
					//loop to summation from 0 up to the size of the layer by multiplying the matrices
					//of the input and the weights and then added to the bias and then use the answer in the sigmoid
					//function
					for(int i = 0; i < hiddenSize; i++){
						for(int j = 0; j < transposedCurrInput[0].length; j++){
							double prod = 0;
							for(int k = 0; k < inputSize; k++) {
								prod += weightsInputToHidden[i][k] * transposedCurrInput[k][j];
							}
							hiddenLayerActivations[i][j] = prod;
						}
					}
					
					
					for(int i = 0; i < hiddenSize; i++){
						for(int j = 0; j < 1; j++){
							hiddenLayerActivations[i][j] += biasesToHidden[i][j];
						}
					}
					
					for(int i = 0; i < hiddenSize; i++){
						for(int j = 0; j < 1; j++){
							hiddenLayerActivations[i][j] = sigmoid(hiddenLayerActivations[i][j]);
						}
					}
					
					//hidden to output
					//loop to summation from 0 up to the size of the layer by multiplying the matrices
					//of the input and the weights and then added to the bias and then use the answer in the sigmoid
					//function
					for(int i = 0; i < outputSize; i++){
						for(int j = 0; j < 1; j++){
							double prod = 0;
							for(int k = 0; k < hiddenSize; k++) {
								prod += hiddenLayerActivations[k][j] * weightsHiddenToOutput[i][k];
							}
							outputLayerActivations[i][0] = prod;
						}
						outputLayerActivations[i][0] += biasesToOutput[i][0];
						outputLayerActivations[i][0] = sigmoid(outputLayerActivations[i][0]);
					}
					
					//check to see if correct number was guessed
					total += 1;
					totalA[indexHotVect(transposeInt(expectedOutput))] += 1;
					if(indexOutputActivation(outputLayerActivations) == indexHotVect(transposeInt(expectedOutput))) {
						correct += 1;
						correctA[indexOutputActivation(outputLayerActivations)] += 1;
					}
				}
			}
			//printing out the accuracy
			for(int i = 0; i < 10; i++) {
				if(i == 6) {
					System.out.println("\n");
				}
				String calcs = String.format("%d = %d / %d ", i, correctA[i], totalA[i]);
				System.out.print(calcs);
			}
			System.out.println(String.format("network accuracy: %d / %d = %f", correct, total, ((double)correct/(double)total)*100));
	}
	// sigmoid activation function
	public static double sigmoid(double x){
		return 1 / (1 + Math.exp(-x));
	}
		
	// derivative of sigmoid function
	public static double sigmoidDerivative(double x){
		return x * (1 - x);
	}
	
	//transpose an int array
	public static int[][] transposeInt(int[] x) {
		int[][] transposedMatrix = new int[x.length][1];
		for(int i = 0; i < x.length; i++) {
			transposedMatrix[i][0] = x[i];
		}
		return transposedMatrix;
	}
	
	//transpose an array
	public static double[][] transposeSingDouble(double[] x) {
		double[][] transposedMatrixSingDoub = new double[x.length][1];
		for(int i = 0; i < x.length; i++) {
			transposedMatrixSingDoub[i][0] = x[i];
		}
		return transposedMatrixSingDoub;
	}
	
	//transpose a double matrix
	public static double[] transposeDouble(double[][] x) {
		double[] transposedMatrix = new double[x.length];
		for(int i = 0; i < x.length; i++) {
			transposedMatrix[i] = x[i][0];
		}
		return transposedMatrix;
	}
	//help to zero out an array
	public static void zeroOutInt(int[] x){
		for(int i = 0; i < x.length; i++) {
			x[i] = 0;
		}
	}
	
	//help to zero out a matrix
	public static void zeroOut(double[][] x){
		for(int i = 0; i < x.length; i++) {
			for(int j = 0; j < x[i].length; j++) {
				x[i][j] = 0;
			}
		}
	}
	//initialize weights with random doubles between each layer
	public static double[][] initRand(double[][] x){
		double[][] init = new double[x.length][x[0].length];
		Random rand = new Random();
		for(int i = 0; i < x.length; i++) {
			for(int j = 0; j < x[i].length; j++) {
				init[i][j] = rand.nextDouble()*2 - 1;
			}
		}
		return init;
	}
	
	//read file and import data from csv file
	public static void readImport(String filename, double[][] inputData, int[][] storeVect) {
		try {
			//open a file using scanner
			File file = new File(filename);
			Scanner scanner = new Scanner(file);
			
			//going through file line by line reading and storing data
			int listIndex = 0;
			while(scanner.hasNextLine()){
				String dataString = scanner.nextLine();
				String[] data = dataString.split(",");
				
				//grabbing label for number
				int label = Integer.parseInt(data[0]);
				int[] hotVect = new int[10];
				for(int i = 0; i < hotVect.length; i++) {
					if(i == label) {
						hotVect[i] = 1;
					}
					else {
						hotVect[i] = 0;
					}
				}
				//storing one hot vect
				storeVect[listIndex] = hotVect;
				
				//store image in input data
				for(int i = 0, j = 1; i < inputData[0].length; i++, j++) {
					double pixel = Integer.parseInt(data[j]);
					pixel = pixel/255;
					inputData[listIndex][i] = pixel;
				}
				listIndex+=1;
			}
		}catch(Exception e) {
			System.out.println("no file found.");
		}
	}
		//find the index at which the value the network classified the value as
		public static int indexOutputActivation(double[][] x) {
			double maxItem = x[0][0];
			int maxItemIndex = 0;
			for(int i = 0; i < x.length; i++) {
				for(int j = 0; j < x[i].length; j++) {
					if(x[i][j] > maxItem) {
						maxItem = x[i][j];
						maxItemIndex = i;
					}
				}
			}
			return maxItemIndex;
		}
		
		//find the true value of the digit (hot vector)
		public static int indexHotVect(int[][] x) {
			int maxItem = x[0][0];
			int maxItemIndex = 0;
			for(int i = 0; i < x.length; i++) {
				for(int j = 0; j < x[i].length; j++) {
					if(x[i][j] > maxItem) {
						maxItem = x[i][j];
						maxItemIndex = i;
					}
				}
			}
			return maxItemIndex;
		}
		
		//randomize the mini-batch data
		public static int[] randMiniBatch() {
			int[] miniIndecies = new int[60000];
			Random rand = new Random();
			for(int i = 0; i < miniIndecies.length; i++) {
				miniIndecies[i] = rand.nextInt(60000);
			}
			return miniIndecies;
		}
		
		//save the weights and biases to a file
		public static void saveNetworkState() {
			try {
				//open file
				FileWriter f = new FileWriter("data/SavedNetwork.txt");
				
				//create buffer writer multiple lines can be written
				BufferedWriter b = new BufferedWriter(f);
				
				//for each line in the weight input to hidden
				for(int i = 0; i < weightsInputToHidden.length; i++) {
					// grabbing a row and converting to string
					String wInputToHidden = Arrays.toString(weightsInputToHidden[i]);
					//take off brackets
					wInputToHidden = wInputToHidden.replace("[", "");
					wInputToHidden = wInputToHidden.replace("]", "");
					b.write(wInputToHidden);
					b.newLine();
				}
				
				//for each line in the weight hidden to output
				for(int i = 0; i < weightsHiddenToOutput.length; i++) {
					// grabbing a row and converting to string
					String wHiddenToOut = Arrays.toString(weightsHiddenToOutput[i]);
					//take off brackets
					wHiddenToOut = wHiddenToOut.replace("[", "");
					wHiddenToOut = wHiddenToOut.replace("]", "");
					b.write(wHiddenToOut);
					b.newLine();
				}
				
				//for each line in the bias input to hidden
				for(int i = 0; i < biasesToHidden.length; i++) {
					// grabbing a row and converting to string
					String bHidden = Arrays.toString(biasesToHidden[i]);
					//take off brackets
					bHidden = bHidden.replace("[", "");
					bHidden = bHidden.replace("]", "");
					b.write(bHidden);
					b.newLine();
				}
				
				//for each line in the weight hidden to output
				for(int i = 0; i < biasesToOutput.length; i++) {
					// grabbing a row and converting to string
					String bOutput = Arrays.toString(biasesToOutput[i]);
					//take off brackets
					bOutput = bOutput.replace("[", "");
					bOutput = bOutput.replace("]", "");
					b.write(bOutput);
					b.newLine();
				}
				//place text in document
				b.flush();
			}catch(Exception e) {}
			
		}
		//load those saves values from the file to their rightful matrices
		public static void loadNetworkState() {
			try {
				//open file
				File file = new File("data/SavedNetwork.txt");
				//read from file
				Scanner s = new Scanner(file);
				
				while(s.hasNextLine()) {
					//for each line in the weight input to hidden
					for(int i = 0; i < weightsInputToHidden.length; i++) {
						// grabbing a row and converting to string
						String wInputToHidden = s.nextLine();
						
						//separate values by commas
						String[] lineItems = wInputToHidden.split(",");
						//turning value back into a double and saving in an array
						for(int j = 0; j < weightsInputToHidden[0].length; j++) {
							weightsInputToHidden[i][j] = Double.parseDouble(lineItems[j]);
						}
					}
					//for each line in the weight input to hidden
					for(int i = 0; i < weightsHiddenToOutput.length; i++) {
						// grabbing a row and converting to string
						String wHiddenToOutput = s.nextLine();
						
						//separate values by commas
						String[] lineItems = wHiddenToOutput.split(",");
						//turning value back into a double and saving in an array
						for(int j = 0; j < weightsHiddenToOutput[0].length; j++) {
							weightsHiddenToOutput[i][j] = Double.parseDouble(lineItems[j]);
						}
					}
					//for each line in the weight input to hidden
					for(int i = 0; i < biasesToHidden.length; i++) {
						// grabbing a row and converting to string
						String bHidden = s.nextLine();
						
						//separate values by commas
						String[] lineItems = bHidden.split(",");
						//turning value back into a double and saving in an array
						for(int j = 0; j < biasesToHidden[0].length; j++) {
							biasesToHidden[i][j] = Double.parseDouble(lineItems[j]);
						}
					}
					//for each line in the weight input to hidden
					for(int i = 0; i < biasesToOutput.length; i++) {
						// grabbing a row and converting to string
						String bOutput = s.nextLine();
						
						//separate values by commas
						String[] lineItems = bOutput.split(",");
						//turning value back into a double and saving in an array
						for(int j = 0; j < biasesToOutput[0].length; j++) {
							biasesToOutput[i][j] = Double.parseDouble(lineItems[j]);
						}
					}
					
				}
			}catch(Exception e) {}
		}
		//print a picture of each digit that is being classified
		public static void printDigit(double[] x) {
			//turning input into 28x28 picture
			double[][] digit = new double[28][28];
			int xIndex = 0;
			
			for(int i = 0; i < digit.length; i++) {
				for(int j = 0; j < digit[0].length; j++) {
					digit[i][j] = x[xIndex];
					xIndex++;
				}
			}
			//print digit
			for(int i = 0; i < digit.length; i++) {
				for(int j = 0; j < digit[0].length; j++) {
					String character = ".";
					if(digit[i][j] == 0) {
						character = "*";
					}
					else{
						character = "@";
					}
					System.out.print(character);
				}
				System.out.println();
			}
		}
		//test the data and display the digits correct and incorrect
		public static void testAndDisplay() {
			//epoch loop goes to 1 epoch as instantiated earlier and it loops the 10000 batches for the epoch
			for(int epoch = 1; epoch < 2; epoch++){
				correct = 0;
				total = 0;
				zeroOutInt(correctA);
				zeroOutInt(totalA);
				
					//mini-batch
					//use the data from the input, and use the expected output to calculate the network accuracy
					for(int miniBatch = 0; miniBatch < 10000; miniBatch++){
						double[] currInput = testingData[miniBatch];
						int[] expectedOutput = testingOneHot[miniBatch];
						
						//forward transversal
						double hiddenLayerActivations[][] = new double[hiddenSize][1];
						double outputLayerActivations[][] = new double[outputSize][1];
						
						//transpose matrix
						double[][] transposedCurrInput = transposeSingDouble(currInput);
						
						//input to hidden
						//loop to summation from 0 up to the size of the layer by multiplying the matrices
						//of the input and the weights and then added to the bias and then use the answer in the sigmoid
						//function
						for(int i = 0; i < hiddenSize; i++){
							for(int j = 0; j < transposedCurrInput[0].length; j++){
								double prod = 0;
								for(int k = 0; k < inputSize; k++) {
									prod += weightsInputToHidden[i][k] * transposedCurrInput[k][j];
								}
								hiddenLayerActivations[i][j] = prod;
							}
						}
						
						
						for(int i = 0; i < hiddenSize; i++){
							for(int j = 0; j < 1; j++){
								hiddenLayerActivations[i][j] += biasesToHidden[i][j];
							}
						}
						
						for(int i = 0; i < hiddenSize; i++){
							for(int j = 0; j < 1; j++){
								hiddenLayerActivations[i][j] = sigmoid(hiddenLayerActivations[i][j]);
							}
						}
						
						//hidden to output
						//loop to summation from 0 up to the size of the layer by multiplying the matrices
						//of the input and the weights and then added to the bias and then use the answer in the sigmoid
						//function
						for(int i = 0; i < outputSize; i++){
							for(int j = 0; j < 1; j++){
								double prod = 0;
								for(int k = 0; k < hiddenSize; k++) {
									prod += hiddenLayerActivations[k][j] * weightsHiddenToOutput[i][k];
								}
								outputLayerActivations[i][0] = prod;
							}
							outputLayerActivations[i][0] += biasesToOutput[i][0];
							outputLayerActivations[i][0] = sigmoid(outputLayerActivations[i][0]);
						}
						
						//print digit
						String s = String.format("Testing case #%d: Correct classification = %d Network Output = %d ", miniBatch, indexHotVect(transposeInt(expectedOutput)),indexOutputActivation(outputLayerActivations));
						if(indexOutputActivation(outputLayerActivations) == indexHotVect(transposeInt(expectedOutput))) {
							s+="correct.";
						}
						else {
							s+="incorrect.";
						}
						System.out.println(s);
						printDigit(testingData[miniBatch]);
						System.out.println("Press [1] to continue. Any other key to go back to menu");
						Scanner scan = new Scanner(System.in);
						int response = scan.nextInt();
						if(response != 1) {
							return;
						}
						//check to see if correct number was guessed
						total += 1;
						totalA[indexHotVect(transposeInt(expectedOutput))] += 1;
						if(indexOutputActivation(outputLayerActivations) == indexHotVect(transposeInt(expectedOutput))) {
							correct += 1;
							correctA[indexOutputActivation(outputLayerActivations)] += 1;
						}
					}
				}
				//printing out the accuracy
				for(int i = 0; i < 10; i++) {
					if(i == 6) {
						System.out.println("\n");
					}
					String calcs = String.format("%d = %d / %d ", i, correctA[i], totalA[i]);
					System.out.print(calcs);
				}
				System.out.println(String.format("network accuracy: %d / %d = %f", correct, total, ((double)correct/(double)total)*100));
		}
		//test and display the inccorrect digits that were classified
		public static void testAndDisplayIncorrect() {
			//epoch loop goes to 1 epochs as instantiated earlier and it loops the 10 batches for the epoch
			for(int epoch = 1; epoch < 2; epoch++){
				correct = 0;
				total = 0;
				zeroOutInt(correctA);
				zeroOutInt(totalA);
				
					//mini-batch
					//use the data from the input, and use the expected output to calculate the network accuracy
					for(int miniBatch = 0; miniBatch < 10000; miniBatch++){
						double[] currInput = testingData[miniBatch];
						int[] expectedOutput = testingOneHot[miniBatch];
						
						//forward transversal
						double hiddenLayerActivations[][] = new double[hiddenSize][1];
						double outputLayerActivations[][] = new double[outputSize][1];
						
						//transpose matrix
						double[][] transposedCurrInput = transposeSingDouble(currInput);
						
						//input to hidden
						//loop to summation from 0 up to the size of the layer by multiplying the matrices
						//of the input and the weights and then added to the bias and then use the answer in the sigmoid
						//function
						for(int i = 0; i < hiddenSize; i++){
							for(int j = 0; j < transposedCurrInput[0].length; j++){
								double prod = 0;
								for(int k = 0; k < inputSize; k++) {
									prod += weightsInputToHidden[i][k] * transposedCurrInput[k][j];
								}
								hiddenLayerActivations[i][j] = prod;
							}
						}
						
						
						for(int i = 0; i < hiddenSize; i++){
							for(int j = 0; j < 1; j++){
								hiddenLayerActivations[i][j] += biasesToHidden[i][j];
							}
						}
						
						for(int i = 0; i < hiddenSize; i++){
							for(int j = 0; j < 1; j++){
								hiddenLayerActivations[i][j] = sigmoid(hiddenLayerActivations[i][j]);
							}
						}
						
						//hidden to output
						//loop to summation from 0 up to the size of the layer by multiplying the matrices
						//of the input and the weights and then added to the bias and then use the answer in the sigmoid
						//function
						for(int i = 0; i < outputSize; i++){
							for(int j = 0; j < 1; j++){
								double prod = 0;
								for(int k = 0; k < hiddenSize; k++) {
									prod += hiddenLayerActivations[k][j] * weightsHiddenToOutput[i][k];
								}
								outputLayerActivations[i][0] = prod;
							}
							outputLayerActivations[i][0] += biasesToOutput[i][0];
							outputLayerActivations[i][0] = sigmoid(outputLayerActivations[i][0]);
						}
						
						if(indexOutputActivation(outputLayerActivations) != indexHotVect(transposeInt(expectedOutput))) {
							
							//print digit
							String s = String.format("Testing case #%d: Correct classification = %d Network Output = %d incorrect.", miniBatch, indexHotVect(transposeInt(expectedOutput)),indexOutputActivation(outputLayerActivations));
							System.out.println(s);
							printDigit(testingData[miniBatch]);
							System.out.println("Press [1] to continue. Any other key to go back to menu");
							Scanner scan = new Scanner(System.in);
							int response = scan.nextInt();
							if(response != 1) {
								return;
							}
						}
						//check to see if correct number was guessed
						total += 1;
						totalA[indexHotVect(transposeInt(expectedOutput))] += 1;
						if(indexOutputActivation(outputLayerActivations) == indexHotVect(transposeInt(expectedOutput))) {
							correct += 1;
							correctA[indexOutputActivation(outputLayerActivations)] += 1;
						}
					}
				}
				//printing out the accuracy
				for(int i = 0; i < 10; i++) {
					if(i == 6) {
						System.out.println("\n");
					}
					String calcs = String.format("%d = %d / %d ", i, correctA[i], totalA[i]);
					System.out.print(calcs);
				}
				System.out.println(String.format("network accuracy: %d / %d = %f", correct, total, ((double)correct/(double)total)*100));
		}
		
}
