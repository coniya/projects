'''
Co'Niya Butler
10383733
November 13, 2023
Assignment 3
Description: This program is of the game Othello in which one can choose to play single player(against computer)
or 2 player mode meaning they can play against another human. In this program there are many different functions
that help each other such as a minimax program that helps the computer pick the best point of play based on the depth chosen.
The player can also choose whether to be the black disk(they go first) or the white disk(other player/computer goes first).
They have the option to turn on and off the alpha beta pruning in the code as well which helps searching for the best play
be more quickly recognized. 
'''

#board 8x8
import random
import sys

#gives the basic outline of the board and prints it out
def drawBoard(board):
    #prints out board that it is passed
    hLine = ' +---+---+---+---+---+---+---+---+'
    vLine = ' |   |   |   |   |   |   |   |   |'

    print(' 1   2   3   4   5   6   7   8')
    print(hLine)
    for y in range(8):
        print(vLine)
        print(y+1, end=' ')
        for x in range(8):
            print('| %s' % (board[x][y]), end=' ')
        print('|')
        print(vLine)
        print(hLine)

#this sets the board up with the initial pieces needed to start the game
def resetBoard(board):
    #sets board up that its passed

    #sets up the rows and columns as empty spaces to be filled later by the player(s) and/or computer
    for x in range(8):
        for y in range(8):
            board[x][y] = ' '

    #starting pieces
    board[3][3] = 'B'
    board[3][4] = 'W'
    board[4][3] = 'W'
    board[4][4] = 'B'

#grabs a completely new and empty board of 8 rows of empty spaces(as a list)
def getNewBoard():
    board = []
    for i in range(8):
        board.append([' '] * 8)
    return board

#check if move is valid
def isValidMove(board, disk, xstart, ystart):
    #returns false if move on the space is invalid
    if((board[xstart][ystart] != ' ') or ( not isOnBoard(xstart, ystart))):
        return False

    #if valid move
    board[xstart][ystart] = disk #temp set disk on board

    #used to keep track of the disks from player(s) and/or computer
    if disk == 'B':
        otherDisk = 'W'
    else:
        otherDisk = 'B'

    # Tracks which disks should be flipped
    disksToFlip = []
    # Search in all valid directions(up, down, left, right, top right, top left, bottom right, and bottom left)
    for xdirection, ydirection in [[0,1],[1,1],[1,0],[1,-1],[0,-1],[-1,-1],[-1,0],[-1,1]]:
        #keeps track of the direction of the piece and starts reading the spaces in all directions
        x,y = xstart, ystart
        #head to the next spot surrounding that piece
        x += xdirection
        y += ydirection
        #checks if there is an opponents piece next to yours
        if isOnBoard(x, y) and board[x][y] == otherDisk:
            #there is the opponents piece next to ours
            #go to next space to check if there is an opponent disk next to it
            x += xdirection
            y += ydirection
            #if out of bounds
            if not isOnBoard(x, y):
                continue
            #keep incrementing to the next position as long as there is an opponent there
            while board[x][y] == otherDisk:
                x += xdirection
                y += ydirection
                #if out of bounds exit loop
                if not isOnBoard(x, y):
                    break
            #out of bounds
            if not isOnBoard(x, y):
                continue
            
            if board[x][y] == disk:
                #reached another of our pieces, so the pieces in between need to be flipped.
                #go back and add all the spaces that contain the opponent to a list to remember
                while True:
                    x -= xdirection
                    y -= ydirection
                    if(x == xstart and y == ystart):
                        break
                    disksToFlip.append([x, y])
    board[xstart][ystart] = ' ' #return board to original state
    #if there are no disks to flip just return false and an empty list
    if(len(disksToFlip) == 0):
        return False
    return disksToFlip

#check if already spot is already marked
def isOnBoard(x,y):
    #returns true if the coordinates are located on the board
    return x >= 0 and x <= 7 and y >= 0 and y <= 7

#get the valid moves for the computer to be able to pick the best move to make
def getValidMoves(board, disk):
    validMoves = []

    #go through each row and column in the board and check if its a valid move for that specific piece
    for x in range(8):
        for y in range(8):
            if isValidMove(board, disk, x, y) != False:
                #if valid move, add it to the list of valid moves
                validMoves.append([x, y])
    return validMoves

#allows us to get the score at any given moment in the game
def getScore(board):
    bScore = 0
    wScore = 0
    #travels through the board and counts each piece so that it knows the score for each player
    for x in range(8):
        for y in range(8):
            if board[x][y] == 'B':
                bScore += 1
            elif board[x][y] == 'W':
                wScore += 1
    return {'B':bScore, 'W':wScore}

#makes the actual move during the game and flips the tiles
def makeTheMove(board, disk, xstart, ystart):
    #place "piece" on the board at the position and flip the opponent's piece
    #return false if invalid move, true if valid
    tilesToFlip = isValidMove(board, disk, xstart, ystart)

    #if there is not a valid move then there will be no tiles to flip
    if tilesToFlip == False:
        return False
    #take the position and place the disk there
    board[xstart][ystart] = disk
    #go through the tilesToFlip list and change the tiles to the current players disk
    for x,y in tilesToFlip:
        board[x][y] = disk
    return True

#make a copy of the current state of the board
def getBoardCopy(board):
    #make a copy of the board and return it
    updatedBoard = getNewBoard()

    for x in range(8):
        for y in range(8):
            updatedBoard[x][y] = board[x][y]

    return updatedBoard

#check if value is in the corner spots
def isOnCorner(x, y):
    #return true if the position is in the one of the four corners
    return (x == 0 and y == 0) or (x == 7  and y == 0) or (x == 0 and y == 7) or (x == 7 and y == 7)

def getPlayerMove(board, playerTile):
    # return move as [x, y]
    digits1to8 = '1 2 3 4 5 6 7 8'.split()

    # Until player enters a valid move
    while True:
        # Ask player for a move
        print('Enter your move as (rowvalue columnvalue): ')
        move = input()
        # If the input is valid, then check if its a valid move
        if(len(move) == 2 and move[0] in digits1to8 and move[1] in digits1to8):
            # Correct offset
            x = int(move[0])-1 
            y = int(move[1])-1
            # Check if move valid
            if isValidMove(board, playerTile, x, y) == False:
                print("You can't place a disk here")
            # Move is valid
            else:
                break
        # Input was invalid
        else:
            print('This is not a valid move. Type the row value (1-8), then the column value (1-8).')
            print('Example, 18 is the top left corner.')
    # Return the valid move
    return x, y

def getAiMove(board, computerDisk):
    # computer determines the best spot to move and returns that move as a list
    possibleMoves = getValidMoves(board, computerDisk)

    #randomize the possible moves so it can learn to choose the right move
    #rather than just going down the same list each time
    random.shuffle(possibleMoves)

    for x,y in possibleMoves:
        if isOnCorner(x,y):
            return x, y

    #go through all possible moves and use minimax/alpha-beta pruning to pick the best move
    #if maximizing
    if(computerDisk == 'B'):
        bestScore = -1
        for x, y in possibleMoves:
            cpyBoard = getBoardCopy(board)
            makeTheMove(cpyBoard, computerDisk, x, y)
            score = minimax(cpyBoard, depth - 1, x, y, False)
            if score > bestScore:
                bestMove = [x, y]
                bestScore = score
        return bestMove
    #if minimizing
    else:
        bestScore = -1
        for x, y in possibleMoves:
            cpyBoard = getBoardCopy(board)
            makeTheMove(cpyBoard, computerDisk, x, y)
            score = minimax(cpyBoard, depth - 1, x, y, True)
            if score < bestScore:
                bestMove = [x, y]
                bestScore = score
        return bestMove
    

#prints the score out
def showScore(playerDisk, computerDisk):
    scores = getScore(mainBoard)
    if(oneOrTwo == 1):
        print(f"You have {scores[playerDisk]}. The computer has {scores[computerDisk]}.")
    else:
        print(f"Player 1 has {scores[playerDisk]}. Player 2 has {scores[computerDisk]}.")

#checks if game is over
def isGameOver():
    return (len(getValidMoves(board, disk)) == 0)
        
#mini-max/alpha-beta pruining
def minimax(board, depth, alpha, beta, maximizingPlayer):
    #if depth is 0 return the heuristic
    if(depth == 0):
        return heuristic()

    #if Black's turn
    validMoves = getValidMoves(mainBoard, maximizingPlayer)
    #computer is the maximizing player
    if maximizingPlayer:
        maxEval = float('-inf')
        #go through each valid move and use the minimax algorithm to find which move willreturn the greatest number of flips
        for move in validMoves:
            cpyBoard = getBoardCopy(mainBoard)
            evaluate = minimax(cpyBoard, depth - 1, alpha, beta, False)
            maxEval = max(maxEval, evaluate)
            alpha = max(alpha, evaluate)
            if(aBP == 'on'):
                print(f"alpha: {alpha} beta: {beta}")
                if(beta <= alpha):
                    break
        return maxEval

    #if White's turn
    else:
        minEval = float('+inf')
        for move in validMoves:
            evaluate = minimax(cpyBoard, depth - 1, alpha, beta, True)
            minEval = min(minEval, evaluate)
            beta = min(beta, eval)
            if(aBP == 'on'):
                print("alpha: {alpha} beta: {beta}")
                if(beta <= alpha):
                    break
        return minEval

def heurisitic():
    b,w = getScore()
    return b - w

def singleOrTwoPlayer():
    sOrM = 0
    while not(sOrM == 1 or sOrM == 2):
        print("Would you like to play 1 player or 2 players? (type 1 or 2 as your choice)")
        sOrM = int(input())
    return sOrM
def playerPickDisk():
    disk = ''
    while not(disk == 'B' or disk == 'W'):
        print("Do you want to be B or W? (black will go first)")
        disk = input().upper()
        
    #first element is player and second is computer
    if(oneOrTwo == 1):
        if(disk == 'B'):
            chosenDisk = ['B','W']
            turn = 'player'
            return chosenDisk, turn
        else:
            chosenDisk = ['W','B']
            turn = 'computer'
            return chosenDisk, turn
    else:
        if(disk == 'B'):
            chosenDisk = ['B','W']
            turn = 'player1'
            return chosenDisk, turn
        else:
            chosenDisk = ['W','B']
            turn = 'player2'
            return chosenDisk, turn
    
def isAlphaBetaPruning():
    onOrOff = ''
    while not(onOrOff == 'on' or onOrOff == 'off'):
        print("would you like alpha beta pruning to be on or off? ")
        onOrOff = input()
    return onOrOff
#####MAIN######
while True:
    mainBoard = getNewBoard()
    resetBoard(mainBoard)
    drawBoard(mainBoard)
    depth = 2
    oneOrTwo = singleOrTwoPlayer()

    ##one player version
    while(oneOrTwo == 1):
        selectedDisk, turn = playerPickDisk()
        aBP = isAlphaBetaPruning()
        while(True):
            if(turn == 'player'):
                # Player 1
                showScore(selectedDisk[0], selectedDisk[1])
                x, y = getPlayerMove(mainBoard, selectedDisk[0])
                makeTheMove(mainBoard, selectedDisk[0], x, y)
                drawBoard(mainBoard)
                if(getValidMoves(mainBoard, selectedDisk[1]) == []):
                    break
                else:
                    print("Its computer's turn")
                    turn = 'computer'
            else:
                # AI makes a move
                showScore(selectedDisk[0], selectedDisk[1])
                x,y = getAiMove(mainBoard, selectedDisk[1])
                makeTheMove(mainBoard, selectedDisk[1], x, y)
                drawBoard(mainBoard)
                if(getValidMoves(mainBoard, selectedDisk[0]) == []):
                    break
                else:
                    print("Your turn")
                    turn = 'player'
        # drawboard
        drawBoard(mainBoard)
        scores = getScore(mainBoard)
        print(f"B scored {scores['B']} points. W scored {scores['W']} points.")
        if(scores[selectedDisk[0]] > scores[selectedDisk[1]]):
            print(f"You beat the computer!! Won by {(scores[selectedDisk[0]] - scores[selectedDisk[1]])}")
        elif(scores[selectedDisk[0]] < scores[selectedDisk[1]]):
            print(f"The computer beat you... Lost by {(scores[selectedDisk[1]] - scores[selectedDisk[0]])}")
        else:
            print("Tie Game!")

    ##two player version
    while(oneOrTwo == 2):
        selectedDisk, turn = playerPickDisk()
        while(True):
            if(turn == 'player1'):
                # Player 1
                showScore(selectedDisk[0], selectedDisk[1])
                x, y = getPlayerMove(mainBoard, selectedDisk[0])
                makeTheMove(mainBoard, selectedDisk[0], x, y)
                drawBoard(mainBoard)
                if(getValidMoves(mainBoard, selectedDisk[1]) == []):
                    break
                else:
                    print("Player 2's turn")
                    turn = 'player2'
            else:
                # player 2 makes a move
                showScore(selectedDisk[0], selectedDisk[1])
                x,y = getPlayerMove(mainBoard, selectedDisk[1])
                makeTheMove(mainBoard, selectedDisk[1], x, y)
                drawBoard(mainBoard)
                if(getValidMoves(mainBoard, selectedDisk[0]) == []):
                    break
                else:
                    print("Player 1's Turn")
                    turn = 'player1'
        # drawboard
        drawBoard(mainBoard)
        scores = getScore(mainBoard)
        print(f"B scored {scores['B']} points. W scored {scores['W']} points.")
        if(scores[selectedDisk[0]] > scores[selectedDisk[1]]):
            print(f"Player 1 won!! player 1 won by {(scores[selectedDisk[0]] - scores[selectedDisk[1]])}")
        elif(scores[selectedDisk[0]] < scores[selectedDisk[1]]):
            print(f"Player 2 won!... Player 2 won by {(scores[selectedDisk[1]] - scores[selectedDisk[0]])}")
        else:
            print("Tie Game!")
        

        
